using UnityEngine;

public class PauseManager : MonoBehaviour
{
    [SerializeField] private GameObject pausePanel;
    [SerializeField] private GameObject mainMenuPanel;
    [SerializeField] private GameObject pauseButton;

    private void Start()
    {
        pausePanel.SetActive(false);
    }

    public void Pause()
    {
        pausePanel.SetActive(true);

        if (pauseButton != null)
        {
            pauseButton.SetActive(false);
        }

        Time.timeScale = 0f;
    }

    public void Resume()
    {
        pausePanel.SetActive(false);

        if (pauseButton != null)
        {
            pauseButton.SetActive(true);
        }

        Time.timeScale = 1f;
    }

    public void Exit()
    {
        pausePanel.SetActive(false);

        if (pauseButton != null)
        {
            pauseButton.SetActive(false);
        }

        if (mainMenuPanel != null)
        {
            mainMenuPanel.SetActive(true);
        }

        Time.timeScale = 0f;
    }
}